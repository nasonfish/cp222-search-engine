javac -cp jsoup.jar:. *.java
java -cp jsoup.jar:. Day11 -v wildanimalsonline.com

